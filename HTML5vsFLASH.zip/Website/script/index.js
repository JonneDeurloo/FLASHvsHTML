// center document
$(document).ready(function () {
    $("#content").css('top', ($(window).height() - $("#content_wrapper").height()) / 2);
});