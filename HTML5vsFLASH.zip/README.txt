# FLASHvsHTML
Deze website is gemaakt als onderdeel van het vak 'Webtechnologie', gegeven aan de Universiteit Utrecht.


## Auteurs:
	Alex Leestemaker, 	5518628
	Jonne Deurloo, 		4120167

## Getest (en werkend) in:
	- Mozilla Firefox 36.0
	- Google Chrome  40.0.2214.115

## Added features:
	- Pijl om terug naar boven te gaan als je midden in de pagina zit.
	- Menu in de pagina HTML5 en Flash die navigeert naar de desbetreffende paragraaf.
	- Sticky header in Compare.
	- De Sitemap staat niet standaard in beeld, door met de muis naar de rechterkant van het beeldscherm te gaan komt deze tevoorschijn.

## Link naar website:
	http://www.students.science.uu.nl/~4120167/	(Jonne)
	http://www.students.science.uu.nl/~5518628/	(Alex)